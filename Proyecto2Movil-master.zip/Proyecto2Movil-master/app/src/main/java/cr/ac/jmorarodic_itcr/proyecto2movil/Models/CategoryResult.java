package cr.ac.jmorarodic_itcr.proyecto2movil.Models;

import java.util.ArrayList;

public class CategoryResult {

    private ArrayList<Category> results;

    public ArrayList<Category> getResults() {
        return results;
    }

    public void setResults(ArrayList<Category> results) {
        this.results = results;
    }


}
