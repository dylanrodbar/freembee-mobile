package cr.ac.jmorarodic_itcr.proyecto2movil;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AnunciosFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AnunciosFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AnunciosFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;


    private MisAnunciosFragment misAnunciosFragment;
    private FavoritosFragment favoritosFragment;
    private Button buttonFavoritos;
    private Button buttonAnuncios;

    SharedPreferences sharedPreferences;
    String tok;
    int idU;

    public AnunciosFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AnunciosFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AnunciosFragment newInstance(String param1, String param2) {
        AnunciosFragment fragment = new AnunciosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View RootView = inflater.inflate(R.layout.fragment_anuncios, container, false);


        buttonAnuncios = RootView.findViewById(R.id.btn_anuncios);
        buttonFavoritos = RootView.findViewById(R.id.btn_favoritos);

        favoritosFragment =  new FavoritosFragment();
        misAnunciosFragment =  new MisAnunciosFragment();

        sharedPreferences = getActivity().getSharedPreferences("Freembe", Context.MODE_PRIVATE);
        tok = sharedPreferences.getString("Token", "No token");
        idU = sharedPreferences.getInt("Id", 0);


        setFragment(misAnunciosFragment);

        buttonAnuncios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonAnuncios.setBackgroundColor(0x1d6177);
                buttonAnuncios.setTextColor(getResources().getColor(R.color.colorWhite));

                buttonFavoritos.setBackgroundColor(getResources().getColor(android.R.color.white));
                buttonFavoritos.setTextColor(getResources().getColor(R.color.colorPrimary));

                setFragment(misAnunciosFragment);
            }
        });

        buttonFavoritos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonAnuncios.setBackgroundColor(getResources().getColor(android.R.color.white));
                buttonAnuncios.setTextColor(getResources().getColor(R.color.colorPrimary));

                buttonFavoritos.setBackgroundColor(0x1d6177);
                buttonFavoritos.setTextColor(getResources().getColor(R.color.colorWhite));

                setFragment(favoritosFragment);
            }
        });

        return RootView;

    }

    private void setFragment(Fragment fragment)
    {
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.anunciosFrame, fragment);
        fragmentTransaction.commit();
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
/*
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }
*/
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
