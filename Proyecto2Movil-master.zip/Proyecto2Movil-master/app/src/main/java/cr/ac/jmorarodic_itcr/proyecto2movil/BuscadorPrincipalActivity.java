package cr.ac.jmorarodic_itcr.proyecto2movil;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BuscadorPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscador_principal);
    }
}
