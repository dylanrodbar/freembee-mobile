# Proyecto2Movil
Aplicación Android del proyecto 2 del curso IC-8041 Desarrollo de Aplicaciones Móviles de la carrera de Ingeniería en Computación del Tecnológico de Costa Rica
